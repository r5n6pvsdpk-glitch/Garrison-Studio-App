(() => {
  const config = window.GARRISON_CONFIG || {};
  const menuToggle = document.getElementById("menuToggle");
  const nav = document.getElementById("mainNav");
  const form = document.getElementById("bookingForm");
  const message = document.getElementById("formMessage");
  const dateInput = form.elements.date;

  // Impedisce la selezione di date passate nel browser.
  const today = new Date();
  const localToday = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  dateInput.min = localToday;

  menuToggle.addEventListener("click", () => {
    const isOpen = nav.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", String(isOpen));
    menuToggle.setAttribute("aria-label", isOpen ? "Chiudi menu" : "Apri menu");
  });
  nav.querySelectorAll("a").forEach(a => a.addEventListener("click", () => {
    nav.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
  }));

  const emailLink = document.getElementById("emailLink");
  const phoneLink = document.getElementById("phoneLink");
  const instagramLink = document.getElementById("instagramLink");
  if (config.email && !config.email.startsWith("INSERISCI")) {
    emailLink.href = `mailto:${config.email}`;
    emailLink.textContent = `Email · ${config.email} ↗`;
  }
  if (config.whatsappNumber) {
    phoneLink.href = `https://wa.me/${config.whatsappNumber}`;
    phoneLink.textContent = "WhatsApp ↗";
  } else if (config.phoneDisplay && !config.phoneDisplay.startsWith("INSERISCI")) {
    phoneLink.href = `tel:${config.phoneDisplay.replace(/[^\d+]/g, "")}`;
    phoneLink.textContent = `Telefono · ${config.phoneDisplay} ↗`;
  }
  if (config.instagramUrl) {
    instagramLink.href = config.instagramUrl;
  } else {
    instagramLink.hidden = true;
  }

  form.addEventListener("submit", event => {
    event.preventDefault();
    message.textContent = "";
    const data = new FormData(form);
    if (!data.get("privacy")) {
      message.textContent = "Conferma la presa visione dell'informativa privacy.";
      return;
    }
    const date = new Date(`${data.get("date")}T12:00:00`).toLocaleDateString("it-IT", {
      weekday: "long", year: "numeric", month: "long", day: "numeric"
    });
    const lines = [
      `RICHIESTA SESSIONE — ${config.studioName || "Garrison Studio"}`,
      "",
      `Nome: ${data.get("name")}`,
      `Nome artistico: ${data.get("artist") || "Non indicato"}`,
      `Email: ${data.get("email")}`,
      `Telefono: ${data.get("phone")}`,
      `Servizio: ${data.get("service")}`,
      `Durata: ${data.get("duration")}`,
      `Data preferita: ${date}`,
      `Fascia oraria: ${data.get("time")}`,
      `Dettagli: ${data.get("details") || "Nessun dettaglio aggiuntivo"}`,
      "",
      "Questa è una richiesta, non una prenotazione confermata."
    ];
    const body = lines.join("\n");
    if (config.bookingMethod === "whatsapp" && config.whatsappNumber) {
      const url = `https://wa.me/${config.whatsappNumber}?text=${encodeURIComponent(body)}`;
      message.textContent = "Si aprirà WhatsApp con la richiesta precompilata. Inviala dalla schermata di WhatsApp.";
      window.open(url, "_blank", "noopener,noreferrer");
    } else if (config.email && !config.email.startsWith("INSERISCI")) {
      const subject = `Richiesta sessione — ${data.get("name")} — ${data.get("date")}`;
      window.location.href = `mailto:${config.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
      message.textContent = "Si aprirà la tua app email con la richiesta precompilata. Premi Invia per consegnarla allo studio.";
    } else {
      message.textContent = "Prima di usare le richieste, il titolare deve inserire un indirizzo email reale nel file config.js. Nessun dato è stato inviato o salvato.";
    }
  });

  if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("./service-worker.js").catch(() => {});
    });
  }

  const privacyLabel = document.querySelector(".consent span");
  if (config.privacyUrl) {
    privacyLabel.innerHTML = `Confermo di aver letto l'<a href="${config.privacyUrl}" target="_blank" rel="noopener" style="text-decoration:underline">informativa privacy</a> dello studio e acconsento a essere ricontattato per questa richiesta.`;
  }
})();
