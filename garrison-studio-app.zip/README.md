# Garrison Studio — web app statica

Questa è una prima versione front-end di una web app installabile sulla schermata Home di iPhone. È realizzata con HTML, CSS e JavaScript vanilla; non richiede un generatore AI, API key o un backend per essere visualizzata.

## Cosa funziona in questa versione

- Sito responsive con sezioni Studio, Servizi, Attrezzatura, Tariffe, Contatti.
- Modulo per preparare una richiesta di sessione.
- Invio della richiesta tramite email (`mailto:`) o WhatsApp (`wa.me`) dopo aver configurato `config.js`.
- Layout PWA, manifest, icona e service worker per caching di base.

## Limiti importanti

- Non c'è un database, un pannello amministratore o un calendario con disponibilità in tempo reale.
- Le richieste non vengono memorizzate dal sito. Il visitatore deve premere Invia nell'app email o WhatsApp.
- Il sito non conferma automaticamente gli appuntamenti, non impedisce sovrapposizioni e non invia notifiche.
- Il service worker/PWA richiede HTTPS o localhost; alcune funzioni di installazione dipendono da iOS/Safari.
- L'immagine hero e quella della sezione attrezzatura sono URL remoti Unsplash e richiedono Internet. Verifica licenza/termini e sostituiscile con foto autorizzate dello studio prima della pubblicazione.
- Prima della pubblicazione inserisci l'informativa privacy reale, contatti, tariffe e attrezzatura effettivamente disponibile.

## Configurazione

Apri `config.js` e sostituisci:
- `email`: email reale che riceverà le richieste.
- `phoneDisplay`: telefono da mostrare.
- `whatsappNumber`: numero internazionale solo cifre, ad esempio `393331234567`.
- `instagramUrl`: URL completo del profilo.
- `bookingMethod`: `email` oppure `whatsapp`.
- `privacyUrl`: link all'informativa privacy.

Non pubblicare finché non hai configurato contatti e privacy. Il consenso attualmente è un segnaposto operativo: deve essere collegato a un'informativa reale.

## Anteprima locale

Apri `index.html` nel browser per una prima anteprima. Per testare PWA/service worker, usa un server locale (ad esempio VS Code Live Server) oppure pubblica il sito su hosting HTTPS.

## Pubblicazione gratuita tramite GitHub Pages

1. Crea un account GitHub se non ne hai già uno.
2. Crea un nuovo repository pubblico, ad esempio `garrison-studio`.
3. Carica tutti i file e la cartella `assets` mantenendo la struttura.
4. Vai in **Settings → Pages**.
5. Scegli **Deploy from a branch**, branch `main`, folder `/ (root)`, poi salva.
6. Attendi il completamento del deploy e apri l'URL fornito da GitHub Pages.
7. Su iPhone apri l'URL in Safari → Condividi → Aggiungi alla schermata Home.

GitHub Pages è un hosting statico: non aggiunge un database, autenticazione o un sistema di prenotazione. Verifica i termini correnti di GitHub e la compatibilità del tuo uso prima di pubblicare.

## Come gestire le richieste

Con questa versione:
1. Il cliente compila il modulo.
2. Si apre la sua app email o WhatsApp con il testo precompilato.
3. Il cliente deve premere Invia.
4. Tu controlli la richiesta e rispondi manualmente.
5. Inserisci l'appuntamento nel tuo calendario separatamente e invii la conferma.

Se vuoi che le richieste siano archiviate automaticamente, che il calendario mostri gli slot liberi o che i clienti possano riprogrammare, serve integrare un servizio di prenotazione/database oppure aggiungere un backend. Non è incluso in questa versione statica e non va considerato disponibile finché non viene configurato e testato.
