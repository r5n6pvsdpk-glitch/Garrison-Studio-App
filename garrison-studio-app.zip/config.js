/*
 * CONFIGURAZIONE GARRISON STUDIO
 * Modifica i valori qui sotto prima di pubblicare.
 * Per richieste via email usa l'indirizzo reale dello studio.
 * Per WhatsApp inserisci solo cifre internazionali, senza +, spazi o trattini.
 */
window.GARRISON_CONFIG = {
  studioName: "Garrison Studio",
  email: "INSERISCI_LA_TUA_EMAIL",
  phoneDisplay: "INSERISCI_IL_TUO_NUMERO",
  whatsappNumber: "", // es. 393331234567
  instagramUrl: "", // es. https://www.instagram.com/tuoprofilo/
  bookingMethod: "email", // "email" oppure "whatsapp"
  privacyUrl: "" // URL della tua informativa privacy pubblicata
};
